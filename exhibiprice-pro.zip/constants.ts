
export const BASE_PRICE_PER_M2 = 40.1166; // Reduced from 42.228 (additional 5% reduction)
export const MIN_PRICE_PER_M2 = 20.0583; // Reduced from 21.114 (additional 5% reduction)
export const DISCOUNT_STEP_M2 = 5;
export const DISCOUNT_RATE_PER_STEP = 0.01; // 1%